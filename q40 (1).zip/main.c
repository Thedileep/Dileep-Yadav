/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<math.h>
int main()
{
    int x1,y1;
    scanf("%d%d",&x1,&y1);
    printf("enter the value of x1=%d and y1=%d\n",x1,y1);
    int x2,y2;
    scanf("%d%d",&x2,&y2);
    printf("enter the value of x2=%d and y2=%d\n",x2,y2);
    float s,a1,a;
    s=(x2-x1)/(y2-y1);
    printf("slope of line:%f\n",s);
    a1=atan(s);
    a=(a1*180)/3.14;
    printf("angle of inclination is:%f",a);
    return 0;
}
