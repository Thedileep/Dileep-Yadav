/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    float a1,a2,a3,a4,a5,t,av,p;
    scanf("%f%f%f%f%f",&a1,&a2,&a3,&a4,&a5);
    t=a1+a2+a3+a4+a5;
    printf(" total value is:%f\n",t);
    av=t/5;
    printf("average value is:%f\n",av);
    p=a1/t*100;
    printf("percentage:%f",p);

    return 0;
}
