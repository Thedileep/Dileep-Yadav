/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    long int total;
    long basic_pay;
    printf("enter the salary");
    scanf("%ld",&basic_pay);
    float HRA=0.15,TA=0.2;
    total= basic_pay +(basic_pay)*HRA+(basic_pay)*TA;
    printf("total=%ld",total);

    return 0;
}
