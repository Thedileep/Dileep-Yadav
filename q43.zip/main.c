/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<math.h>
int main()
{
   int v,u=30,a=5,d=70;
   printf("initial velocity of car:30m/s\n");
   printf("accelaration of car:5m/s^2\n");
   printf("distance:70m\n");
   v=sqrt(pow(u,2)+2*a*d);
   printf(" final velocity:%d",v);

    return 0;
}
