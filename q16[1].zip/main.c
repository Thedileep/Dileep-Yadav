/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a,d,n,p,q;
    scanf("%d%d%d",&a,&d,&n);
    p=a+(n-1)*d;
    printf("nth term:%d\n",p);
    q=n*(2*a+(n-1)*d)/2;
    printf("sum of nth term:%d",q);

    return 0;
}
