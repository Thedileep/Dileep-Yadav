/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int f1=20,f2=30,p1,p2,tp;
    printf("the population is:30000\n");
    p1=30000*f1/100+30000;
    printf(" total population in 1st year is:%d\n",p1);
    p2=30000*f2/100+30000;
    printf("total population in 2nd year is:%d\n",p2);
    tp=p1+p2;
    printf("total population after 2 years is:%d",tp);

    return 0;
}
