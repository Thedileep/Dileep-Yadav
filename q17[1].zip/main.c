/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int l,b,p;
    scanf("%d",&l);
    printf("enter  length:%d\n",l);
    scanf("%d",&b);
    printf("enter breadth:%d\n",b);
    p=2*(l+b);
    printf("perimeter of rectangle:%d\n",p);

    return 0;
}
