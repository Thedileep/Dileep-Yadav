/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a=4,b=6;
    a=a+b;
    b=a-b;
    a=a-b;
    printf("swap no.of a=%d\n",a);
     printf("swap no.of b=%d",b);

    return 0;
}
