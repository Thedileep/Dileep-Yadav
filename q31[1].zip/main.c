/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<math.h>
int main()
{
    float p,n,t,r,ci;
    scanf("%f",&n);
  scanf("%f",&p);
  printf("enter the value of p:%f\n",p);
  scanf("%f",&t);
  printf("enter the value of t:%f\n",t);
  scanf("%f",&r);
  printf("enter the value of r:%f\n",r);
  ci=pow(p*(1+r/n),n*t);
  printf("compound intrest:%f",ci);
  

    return 0;
}
