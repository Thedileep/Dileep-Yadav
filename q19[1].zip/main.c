/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int r,d,c,a;
    scanf("%d",&r);
    printf("enter radius:%d\n",r);
    d=2*r;
    printf("diameter:%d\n",d);
    c=2*3.14*r;
    printf("circumference:%d\n",c);
    a=3.14*r*r;
    printf("area:%d\n",a);

    

    return 0;
}
