/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    float x,x1,sum;
    scanf("%f",&x);
    printf("enter value of x:%f\n",x);
    x1=x;
   
    printf("enter the same value of x for x1:%f\n",x1);
    sum=x+x1;
    printf("sum of n0. using float is:%f",sum);

    return 0;
}
