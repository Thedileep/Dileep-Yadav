/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<math.h>
int main()
{
  int u=0,a=4,t=3,v,s;
  printf("intial velocity=0\n time=3s\n accelaration=4m/s^2\n");
  v=u+a*t;
  printf("(a) final velocity=%d\n",v);
  s=u*t+0.5*a*pow(t,2);
  printf("(b) distance=%d",s);

    return 0;
}
