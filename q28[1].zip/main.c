/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
     float s,a;
    scanf("%f",&s);
    printf("side of equilateral triangle:%f\n",s);
    a=s*s*1.73/4;
    printf("area of equilateral triangle is:%f",a);

    return 0;
}
