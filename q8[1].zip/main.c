/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a;
    float b;
    double c;
    long double d;
    printf("size= %zu bytes\n",sizeof(a));
    printf("size= %zu bytes\n",sizeof(b));
    printf("size= %zu bytes\n",sizeof(c));
    printf("size= %zu bytes\n",sizeof(d));
    

    return 0;
}
