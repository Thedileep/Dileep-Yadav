/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int x,y,z;
    scanf("%d",&x);
    printf("enter the angle of triangle x:%d\n",x);
    scanf("%d",&y);
    printf("enter the angle of triangle y:%d\n",y);
    z=180-(x+y);
    printf("angle of triangle z is:%d",z);

    return 0;
}
